Files in this folder:
0) Other : Excess data
1) project report in pdf
2) project presentation
3)cars_data .csv (collected by scraping)
4)Code used to scrape data
5) ML Model made in Jupyter notebook