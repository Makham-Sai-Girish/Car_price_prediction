Car details collected from other websites,  but not used in building model.

Code and .csv  files of data in this folder